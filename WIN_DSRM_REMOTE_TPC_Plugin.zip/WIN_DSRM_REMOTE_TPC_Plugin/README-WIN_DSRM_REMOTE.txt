WIN_DSRM_REMOTE - CyberArk TPC DSRM Remote Reset Starter Plugin
================================================================

Purpose
-------
This starter plugin supports Option A for DSRM password management:
CyberArk CPM starts a PowerShell wrapper locally; the wrapper authenticates to
an approved Domain Controller using a linked execution account over WinRM; the
Domain Controller runs ntdsutil.exe locally with:

    set dsrm password
    reset password on server null

NTDSUTIL is not required on the CPM server.

Files
-----
DSRMRemoteProcess.ini
    TPC process file. Starts the PowerShell wrapper, sends linked account
    password and generated DSRM password through TPC stdin prompts, and returns
    success/failure to CPM.

DSRMRemotePrompts.ini
    TPC prompts file. Matches wrapper input prompts, success sentinel, and
    failure sentinel.

bin\WIN_DSRM_REMOTE\Invoke-DSRMRemoteReset.ps1
    Main wrapper. Uses WinRM/PowerShell Remoting to execute NTDSUTIL locally on
    the target DC. Handles HTTPS or HTTP/Kerberos, event validation, NTDSUTIL
    output parsing, and known failure patterns.

Test-DSRMRemotePrereqs.ps1
    Manual pre-flight script to run from the CPM server before CyberArk testing.
    It validates TCP/WinRM reachability, session creation, DC role, target-side
    NTDSUTIL availability, and Event ID 4794 query access.

Policy-WIN_DSRM_REMOTE.ini / Policy-WIN_DSRM_REMOTE.xml
    Starter platform policy files. Use your exported working CyberArk platform
    as the authoritative base and merge the important values.

sample-DSRMRemote-params.ini
    Manual TPC test parameter file example.

Recommended CyberArk account model
----------------------------------
Target DSRM account, one per DC:

    Platform: WIN_DSRM_REMOTE
    Address : DC01.domain.com
    Username: Administrator
    Password: Current DSRM password for DC01
    Object  : DSRM-DC01

Linked execution account:

    Platform: Windows Domain Account
    Username: DOMAIN\svc_cyberark_dsrm_reset
    Password: Current AD password
    Link as : LogonAccount / extrapass1

The linked execution account is used to open the WinRM session and run NTDSUTIL.
The DSRM account itself is the managed target credential and is not used to
connect remotely.

Default transport
-----------------
Default is HTTPS WinRM:

    WinRMTransport=HTTPS
    WinRMPort=5986
    WinRMAuthentication=Default

For HTTP/Kerberos:

    WinRMTransport=HTTP
    WinRMPort=5985
    WinRMAuthentication=Kerberos

Security recommendation: prefer HTTPS/5986 where available and scope inbound
WinRM on DCs to approved CyberArk CPM servers only.

Pre-flight test from CPM
------------------------
Run from the CPM server before triggering CyberArk CPM:

    $cred = Get-Credential DOMAIN\svc_cyberark_dsrm_reset
    .\Test-DSRMRemotePrereqs.ps1 -TargetServer dc01.domain.com -Credential $cred -Transport HTTPS -Authentication Default -Port 5986

For HTTP/Kerberos:

    $cred = Get-Credential DOMAIN\svc_cyberark_dsrm_reset
    .\Test-DSRMRemotePrereqs.ps1 -TargetServer dc01.domain.com -Credential $cred -Transport HTTP -Authentication Kerberos -Port 5985

Manual TPC test
---------------
1. Copy files to the CPM Password Manager folder structure.
2. Open an elevated command prompt or the same service context used for plugin testing.
3. Set secrets for manual testing:

    set pmextrapass1=LinkedAccountPasswordHere
    set pmnewpass=NewDSRMPasswordHere

4. Run logon/prerequisite test:

    bin\CyberArk.TPC.exe sample-DSRMRemote-params.ini logon

5. Run change test against a non-production DC:

    bin\CyberArk.TPC.exe sample-DSRMRemote-params.ini changepass

CyberArk CPM actions
--------------------
logon:
    Pre-check only. Opens WinRM session, confirms target is a DC, confirms
    ntdsutil.exe exists on the DC.

verifypass:
    Same as logon. True DSRM verification is intentionally not performed because
    it requires booting the DC into Directory Services Restore Mode.

prereconcilepass:
    Same as logon, using the linked execution account.

changepass:
    Resets DSRM password on the target DC to CPM-generated pmnewpass.

reconcilepass:
    Resets DSRM password on the target DC to CPM-generated pmnewpass.

Event validation
----------------
EventValidationMode controls how Security Event ID 4794 is handled:

    Off     = do not query event log
    Warn    = query event log, but do not fail solely because event read fails
    Require = fail if Event ID 4794 success cannot be confirmed

Recommended lab setting: Warn
Recommended production setting after validation: Require, if the linked account
can read the DC Security log.

Password character considerations
---------------------------------
This wrapper does not pass the DSRM password on the command line. It reads
pmnewpass through stdin and passes the value to the remote script over WinRM.
This avoids most quoting issues with characters like quotes, ampersand, pipe,
backtick, dollar sign, and spaces.

Do not allow CR, LF, or null characters in generated passwords. NTDSUTIL uses
line-oriented prompts, so newline characters would break the command sequence.
The default starter policy uses a 24-character password with at least 2 upper,
2 lower, 2 digits, and 2 specials. Adjust this to meet your domain password
filters. DSRM password reset is still subject to domain password complexity and
password filter DLLs.

Common failures and likely cause
--------------------------------
CA_DSRM_FAILURE: TCP/WinRM connection failed
    Firewall, WinRM listener, SPN/Kerberos, DNS, or target availability issue.

CA_DSRM_FAILURE: Access is denied
    Linked execution account cannot remote to the DC, cannot run NTDSUTIL, or
    does not have DC admin/delegated rights to reset DSRM.

CA_DSRM_FAILURE: ntdsutil.exe was not found on the target DC
    Unexpected target OS/path issue. Verify C:\Windows\System32\ntdsutil.exe.

CA_DSRM_FAILURE: target does not report as Domain Controller
    Address points to the wrong server or WinRM endpoint redirects unexpectedly.

CA_DSRM_FAILURE: password filter / complexity / does not meet
    The CPM-generated password violates domain password policy, custom password
    filter, or Microsoft Entra Password Protection agent policy.

CA_DSRM_FAILURE: Event ID 4794 was not confirmed
    NTDSUTIL output did not show a success phrase and the plugin could not
    confirm Event ID 4794. Review DC Security log and wrapper log.

Logs
----
Wrapper log path on CPM:

    C:\ProgramData\CyberArk\DSRMRemote\DSRMRemote_<action>_<timestamp>.log

The log redacts linked execution password and new DSRM password.

Deployment notes
----------------
- Validate with the CyberArk TPC Code Analyzer before production use.
- Keep MaxConcurrentConnections=1.
- Start with manual change only; do not enable periodic change until lab testing
  confirms command flow, WinRM, permissions, password policy, and Event ID 4794.
- Use a non-production DC first.
- The DC does not need to reboot for the password reset to take effect. Reboot is
  only needed if the AD team wants to perform an actual DSRM login test.
