<#
.SYNOPSIS
    Pre-flight validator for the CyberArk DSRM Remote TPC plugin.

.DESCRIPTION
    Run this from the CPM server using the same execution account that will be
    linked in CyberArk. This validates network reachability, WinRM session
    creation, target DC role, and existence of ntdsutil.exe on the target DC.
    It does not change the DSRM password.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$TargetServer,

    [Parameter(Mandatory = $true)]
    [System.Management.Automation.PSCredential]$Credential,

    [Parameter(Mandatory = $false)]
    [ValidateSet('HTTPS','HTTP')]
    [string]$Transport = 'HTTPS',

    [Parameter(Mandatory = $false)]
    [ValidateSet('Default','Kerberos','Negotiate','Credssp')]
    [string]$Authentication = 'Default',

    [Parameter(Mandatory = $false)]
    [int]$Port = 0,

    [Parameter(Mandatory = $false)]
    [string]$RemoteNtdsutilPath = 'C:\Windows\System32\ntdsutil.exe'
)

$ErrorActionPreference = 'Continue'
$useSsl = $Transport -eq 'HTTPS'
if ($Port -eq 0) { $Port = if ($useSsl) { 5986 } else { 5985 } }

Write-Host '============================================================'
Write-Host 'DSRM Remote Plugin Prerequisite Validation'
Write-Host '============================================================'
Write-Host "Target      : $TargetServer"
Write-Host "Transport   : $Transport"
Write-Host "Port        : $Port"
Write-Host "Auth        : $Authentication"
Write-Host "Credential  : $($Credential.UserName)"
Write-Host ''

try {
    $tcp = New-Object Net.Sockets.TcpClient
    $iar = $tcp.BeginConnect($TargetServer, $Port, $null, $null)
    $ok = $iar.AsyncWaitHandle.WaitOne(5000, $false)
    if ($ok -and $tcp.Connected) {
        Write-Host "[PASS] TCP $Port reachable on $TargetServer" -ForegroundColor Green
    } else {
        Write-Host "[FAIL] TCP $Port not reachable or timed out on $TargetServer" -ForegroundColor Red
    }
    $tcp.Close()
} catch {
    Write-Host "[FAIL] TCP test failed: $($_.Exception.Message)" -ForegroundColor Red
}

try {
    $params = @{ ComputerName = $TargetServer; Credential = $Credential; Port = $Port; ErrorAction = 'Stop' }
    if ($useSsl) { $params.UseSSL = $true }
    if ($Authentication -ne 'Default') { $params.Authentication = $Authentication }
    $session = New-PSSession @params
    Write-Host '[PASS] New-PSSession succeeded.' -ForegroundColor Green

    $remote = Invoke-Command -Session $session -ArgumentList $RemoteNtdsutilPath -ScriptBlock {
        param([string]$Path)
        $cs = Get-CimInstance Win32_ComputerSystem
        $ntds = if (Test-Path -LiteralPath $Path) { (Resolve-Path -LiteralPath $Path).Path } else { $null }
        [pscustomobject]@{
            ComputerName = $env:COMPUTERNAME
            DomainRole = $cs.DomainRole
            IsDomainController = ($cs.DomainRole -eq 4 -or $cs.DomainRole -eq 5)
            NtdsutilPath = $ntds
            CanReadSecurity4794 = $false
            Security4794ReadError = $null
        }
    }

    if ($remote.IsDomainController) {
        Write-Host "[PASS] Target reports as Domain Controller. DomainRole=$($remote.DomainRole)" -ForegroundColor Green
    } else {
        Write-Host "[FAIL] Target does not report as Domain Controller. DomainRole=$($remote.DomainRole)" -ForegroundColor Red
    }

    if ($remote.NtdsutilPath) {
        Write-Host "[PASS] ntdsutil.exe found on target: $($remote.NtdsutilPath)" -ForegroundColor Green
    } else {
        Write-Host "[FAIL] ntdsutil.exe not found on target at $RemoteNtdsutilPath" -ForegroundColor Red
    }

    try {
        $eventTest = Invoke-Command -Session $session -ScriptBlock {
            try {
                $null = Get-WinEvent -FilterHashtable @{ LogName = 'Security'; Id = 4794; StartTime = (Get-Date).AddDays(-30) } -MaxEvents 1 -ErrorAction Stop
                'PASS'
            } catch {
                "WARN: $($_.Exception.Message)"
            }
        }
        if ($eventTest -eq 'PASS') {
            Write-Host '[PASS] Security Event ID 4794 can be queried on the DC.' -ForegroundColor Green
        } else {
            Write-Host "[WARN] Security Event ID 4794 query warning: $eventTest" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "[WARN] Could not test Event ID 4794 access: $($_.Exception.Message)" -ForegroundColor Yellow
    }

    Remove-PSSession -Session $session
} catch {
    Write-Host "[FAIL] WinRM/PowerShell Remoting validation failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host 'Done.'
